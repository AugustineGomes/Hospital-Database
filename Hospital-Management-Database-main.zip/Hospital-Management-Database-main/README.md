# Hospital-Management-Database
This management system will be used to keep records of details in the hospital
