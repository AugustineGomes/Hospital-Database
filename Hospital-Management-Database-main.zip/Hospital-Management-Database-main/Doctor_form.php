<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " .mysqli_connect_error());
}
$D_ID=$_POST['D_ID'];
$FIRST_NAME=$_POST['FIRST_NAME'];
$LAST_NAME=$_POST['LAST_NAME'];
$PHONE_NUMBER=$_POST['PHONE_NUMBER'];
$SPECIALTY=$_POST['SPECIALTY'];
$SALARY=$_POST['SALARY'];
$sql = "INSERT INTO doctor(D_ID, FIRST_NAME, LAST_NAME, PHONE_NUMBER, SPECIALTY, SALARY)
VALUES ('$D_ID', '$FIRST_NAME', '$LAST_NAME','$PHONE_NUMBER', '$SPECIALTY','$SALARY')";



if(mysqli_query($conn,$sql))
{
  echo "<script>alert('Data Entry Succesful');</script>";
  echo "<script>document location = 'CSEproject311/Doctor_form.html';</script>";
}
else{
  echo "<script>alert('Something Went Wrong');</script>";
}
?>